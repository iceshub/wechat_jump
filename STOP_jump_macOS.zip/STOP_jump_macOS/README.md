## 微信跳一跳自动化app

### 操作说明

- 请确保手机连接并打开调试功能，双击 one_step_auto_beta1 文件即可

### FAQ

- 因为程序会下载必要软件，所以前期工作取决于网速。当运行完一次，对于重新运行的步骤可以使用`control+c`来结束重新安装，程序将继续进行。
- 如遇到不能执行情况，请在终端上使用 `chmod +x` 命令对文件进行可执行赋权，然后再双击
- 更多问题请查阅 [FAQ](https://github.com/wangshub/wechat_jump_game/wiki/FAQ)

